package com.example.gestion_notificaciones.Controller;

import com.example.gestion_notificaciones.Model.Notificacion; 
import com.example.gestion_notificaciones.Service.NotificacionService; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/notificaciones")
public class NotificacionController {

    @Autowired
    private NotificacionService notificacionService;

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Notificacion notificacion) {
        try {
            Notificacion nuevaNotificacion = notificacionService.crearNotificacion(notificacion);
            return ResponseEntity.ok(nuevaNotificacion);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error al crear notificación: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error inesperado al crear notificación: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
public ResponseEntity<?> obtener(@PathVariable Long id) {
    try {
        Optional<Notificacion> n = notificacionService.obtenerPorId(id);
        if (n.isPresent()) {
            return ResponseEntity.ok(n.get());
        } else {
            return ResponseEntity.status(404).body("Notificación no encontrada con ID: " + id);
        }
    } catch (Exception e) {
        return ResponseEntity.internalServerError().body("Error al obtener notificación: " + e.getMessage());
    }
}


    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> porUsuario(@PathVariable Long usuarioId) {
        try {
            List<Notificacion> notificaciones = notificacionService.obtenerPorUsuario(usuarioId);
            return ResponseEntity.ok(notificaciones);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener notificaciones por usuario: " + e.getMessage());
        }
    }

    @PutMapping("/{id}/leida")
    public ResponseEntity<?> marcarLeida(@PathVariable Long id) {
        try {
            Notificacion notificacionActualizada = notificacionService.marcarComoLeida(id);
            return ResponseEntity.ok(notificacionActualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error inesperado al marcar como leída: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            notificacionService.eliminarNotificacion(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al eliminar notificación: " + e.getMessage());
        }
    }
}
