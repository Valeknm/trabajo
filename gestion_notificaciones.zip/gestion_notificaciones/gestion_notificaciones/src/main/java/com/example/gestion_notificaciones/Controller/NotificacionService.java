package com.example.gestion_notificaciones.Controller;

import java.util.Optional;

import com.example.gestion_notificaciones.Model.Notificacion;

public class NotificacionService {

    public Notificacion crearNotificacion(Notificacion notificacion) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'crearNotificacion'");
    }

    public Optional<Notificacion> obtenerPorId(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'obtenerPorId'");
    }

    public Object obtenerPorUsuario(Long usuarioId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'obtenerPorUsuario'");
    }

    public Object marcarComoLeida(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'marcarComoLeida'");
    }

    public void eliminarNotificacion(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminarNotificacion'");
    }

}
