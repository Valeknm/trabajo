package com.example.gestion_notificaciones.Service; 

import com.example.gestion_notificaciones.Model.Notificacion; 
import com.example.gestion_notificaciones.Repository.NotificacionRepository; 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository notificacionRepository;

    private final WebClient usuarioWebClient;
    private final WebClient invitadoWebClient;

    public NotificacionService(WebClient.Builder webClientBuilder) {
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
        this.invitadoWebClient = webClientBuilder.baseUrl("http://localhost:8083/invitados").build();
    }

    public Notificacion crearNotificacion(Notificacion notificacion) {
        Boolean usuarioOInvitadoExiste = validarUsuarioOInvitadoExistente(notificacion.getUsuarioId())
                                        .block();

        if (usuarioOInvitadoExiste == null || !usuarioOInvitadoExiste) {
            throw new RuntimeException("El ID proporcionado no corresponde a un usuario o invitado válido.");
        }

        notificacion.setLeida(false);
        notificacion.setFechaEnvio(LocalDateTime.now());
        return notificacionRepository.save(notificacion);
    }

    public Optional<Notificacion> obtenerPorId(Long id) {
        return notificacionRepository.findById(id);
    }

    public List<Notificacion> obtenerPorUsuario(Long usuarioId) {
        return notificacionRepository.findByUsuarioId(usuarioId);
    }

    public Notificacion marcarComoLeida(Long id) {
        return notificacionRepository.findById(id).map(n -> {
            n.setLeida(true);
            return notificacionRepository.save(n);
        }).orElseThrow(() -> new RuntimeException("Notificación no encontrada con ID: " + id));
    }

    public void eliminarNotificacion(Long id) {
        notificacionRepository.deleteById(id);
    }

    private Mono<Boolean> validarUsuarioOInvitadoExistente(Long id) {
        return usuarioWebClient.get()
                .uri("/{id}", id)
                .retrieve()
                .bodyToMono(Object.class)
                .map(user -> true)
                .onErrorResume(WebClientResponseException.class, e -> {
                    if (e.getStatusCode().is4xxClientError()) {
                        return invitadoWebClient.get()
                                .uri("/{id}", id)
                                .retrieve()
                                .bodyToMono(Object.class)
                                .map(invitado -> true)
                                .onErrorResume(WebClientResponseException.class, e2 -> {
                                    if (e2.getStatusCode().is4xxClientError()) {
                                        return Mono.just(false);
                                    } else {
                                        return Mono.error(new RuntimeException("Error del servidor al validar invitado: " + e2.getStatusCode()));
                                    }
                                })
                                .defaultIfEmpty(false);
                    } else {
                        return Mono.error(new RuntimeException("Error del servidor al validar usuario: " + e.getStatusCode()));
                    }
                })
                .defaultIfEmpty(false);
    }
}