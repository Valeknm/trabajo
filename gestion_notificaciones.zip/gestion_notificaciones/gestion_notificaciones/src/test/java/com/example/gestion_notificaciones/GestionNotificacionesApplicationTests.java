package com.example.gestion_notificaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionNotificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
