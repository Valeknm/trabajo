package com.example.gestion_invitados.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_invitados.Model.Invitado;
import com.example.gestion_invitados.Repository.InvitadoRepository;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class InvitadoService {

    @Autowired
    private InvitadoRepository invitadoRepository;

    private final WebClient eventoWebClient;

    public InvitadoService(WebClient.Builder webClientBuilder) {
        this.eventoWebClient = webClientBuilder.baseUrl("http://localhost:8082/eventos").build();
    }

    public Invitado crearInvitado(Invitado invitado) {
        if (invitado.getEventoId() != null) {
            Boolean eventoExiste = validarEventoExistente(invitado.getEventoId()).block();
            if (eventoExiste == null || !eventoExiste) {
                throw new RuntimeException("El evento con ID " + invitado.getEventoId() + " no existe.");
            }
        }
        return invitadoRepository.save(invitado);
    }

    public Optional<Invitado> obtenerInvitadoPorId(Long id) {
        return invitadoRepository.findById(id);
    }

    public List<Invitado> obtenerInvitadosPorEvento(Long eventoId) {
        return invitadoRepository.findByEventoId(eventoId);
    }

    public Invitado actualizarInvitado(Long id, Invitado actualizado) {
        return invitadoRepository.findById(id).map(invitado -> {
            invitado.setNombre(actualizado.getNombre());
            invitado.setCorreo(actualizado.getCorreo());
            invitado.setConfirmacionAsistencia(actualizado.getConfirmacionAsistencia());
            invitado.setRestriccionesAlimentarias(actualizado.getRestriccionesAlimentarias());

            if (actualizado.getEventoId() != null) {
                Boolean eventoExiste = validarEventoExistente(actualizado.getEventoId()).block();
                if (eventoExiste == null || !eventoExiste) {
                    throw new RuntimeException("Nuevo Evento con ID " + actualizado.getEventoId() + " no encontrado.");
                }
                invitado.setEventoId(actualizado.getEventoId());
            }

            return invitadoRepository.save(invitado);
        }).orElseThrow(() -> new RuntimeException("Invitado no encontrado con ID: " + id));
    }

    public void eliminarInvitado(Long id) {
        invitadoRepository.deleteById(id);
    }

    private Mono<Boolean> validarEventoExistente(Long eventoId) {
        return eventoWebClient.get()
                .uri("/{id}", eventoId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar EventoService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(event -> true)
                .defaultIfEmpty(false);
    }
}
