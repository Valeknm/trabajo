package com.example.gestion_invitados.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gestion_invitados.Model.Invitado;
import com.example.gestion_invitados.Service.InvitadoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/invitados")
public class InvitadoController {

    @Autowired
    private InvitadoService invitadoService;

    @PostMapping
    public ResponseEntity<?> crearInvitado(@RequestBody Invitado invitado) {
        try {
            Invitado invitadoCreado = invitadoService.crearInvitado(invitado);
            return ResponseEntity.ok(invitadoCreado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error interno del servidor: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Invitado> obtenerInvitado(@PathVariable Long id) {
        Optional<Invitado> invitado = invitadoService.obtenerInvitadoPorId(id);
        return invitado.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/evento/{eventoId}")
    public ResponseEntity<List<Invitado>> obtenerInvitadosPorEvento(@PathVariable Long eventoId) {
        return ResponseEntity.ok(invitadoService.obtenerInvitadosPorEvento(eventoId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarInvitado(@PathVariable Long id, @RequestBody Invitado invitado) {
        try {
            Invitado invitadoActualizado = invitadoService.actualizarInvitado(id, invitado);
            return ResponseEntity.ok(invitadoActualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error interno del servidor: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInvitado(@PathVariable Long id) {
        invitadoService.eliminarInvitado(id);
        return ResponseEntity.noContent().build();
    }
}
