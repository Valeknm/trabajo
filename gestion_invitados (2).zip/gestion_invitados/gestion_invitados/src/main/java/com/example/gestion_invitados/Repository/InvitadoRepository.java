package com.example.gestion_invitados.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_invitados.Model.Invitado;

import java.util.List;

public interface InvitadoRepository extends JpaRepository<Invitado, Long> {
    List<Invitado> findByEventoId(Long eventoId);
}