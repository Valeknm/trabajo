package com.example.gestion_invitados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionInvitadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionInvitadosApplication.class, args);
	}

}
