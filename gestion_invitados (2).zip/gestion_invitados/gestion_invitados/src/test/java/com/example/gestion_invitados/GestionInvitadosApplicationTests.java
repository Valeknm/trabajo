package com.example.gestion_invitados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionInvitadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
