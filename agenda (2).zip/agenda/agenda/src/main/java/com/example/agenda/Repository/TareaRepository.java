package com.example.agenda.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.agenda.Model.Tarea;

import java.util.List;

public interface TareaRepository extends JpaRepository<Tarea, Long> {
    List<Tarea> findByEventoId(Long eventoId);
    List<Tarea> findByResponsableId(Long responsableId);
    List<Tarea> findByEventoIdAndEstado(Long eventoId, String estado);
}
