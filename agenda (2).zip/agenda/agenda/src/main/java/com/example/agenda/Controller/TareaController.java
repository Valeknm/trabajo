package com.example.agenda.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.agenda.Model.Tarea;
import com.example.agenda.Service.TareaService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/tareas")
public class TareaController {

    @Autowired
    private TareaService tareaService;

    @PostMapping
    public ResponseEntity<?> crearTarea(@RequestBody Tarea tarea) {
        try {
            Tarea tareaCreada = tareaService.crearTarea(tarea);
            return ResponseEntity.ok(tareaCreada);
        } catch (RuntimeException e) {
            // Error de validación o error lanzado por el servicio
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            // Error inesperado
            return ResponseEntity.status(500).body("Error interno del servidor: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtenerTarea(@PathVariable Long id) {
        Optional<Tarea> tarea = tareaService.obtenerTareaPorId(id);
        return tarea.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/evento/{eventoId}")
    public ResponseEntity<List<Tarea>> obtenerTareasPorEvento(@PathVariable Long eventoId) {
        return ResponseEntity.ok(tareaService.obtenerTareasPorEvento(eventoId));
    }

    @GetMapping("/responsable/{responsableId}")
    public ResponseEntity<List<Tarea>> obtenerTareasPorResponsable(@PathVariable Long responsableId) {
        return ResponseEntity.ok(tareaService.obtenerTareasPorResponsable(responsableId));
    }

    @GetMapping("/evento/{eventoId}/estado/{estado}")
    public ResponseEntity<List<Tarea>> obtenerTareasPorEstadoEnEvento(@PathVariable Long eventoId, @PathVariable String estado) {
        return ResponseEntity.ok(tareaService.obtenerTareasPorEstadoEnEvento(eventoId, estado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarTarea(@PathVariable Long id, @RequestBody Tarea tarea) {
        try {
            Tarea tareaActualizada = tareaService.actualizarTarea(id, tarea);
            return ResponseEntity.ok(tareaActualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error interno del servidor: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarTarea(@PathVariable Long id) {
        tareaService.eliminarTarea(id);
        return ResponseEntity.noContent().build();
    }
}
