package com.example.agenda.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.example.agenda.Model.Tarea;
import com.example.agenda.Repository.TareaRepository;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class TareaService {

    @Autowired
    private TareaRepository tareaRepository;

    private final WebClient eventoWebClient;
    private final WebClient usuarioWebClient;

    public TareaService(WebClient.Builder webClientBuilder) {
        this.eventoWebClient = webClientBuilder.baseUrl("http://localhost:8082/eventos").build();
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
    }

    public Tarea crearTarea(Tarea tarea) {
        if (tarea.getEventoId() != null) {
            Boolean eventoExiste = validarEventoExistente(tarea.getEventoId()).block();
            if (eventoExiste == null || !eventoExiste) {
                throw new RuntimeException("El evento con ID " + tarea.getEventoId() + " no existe.");
            }
        }
        if (tarea.getResponsableId() != null) {
            Boolean usuarioExiste = validarUsuarioExistente(tarea.getResponsableId()).block();
            if (usuarioExiste == null || !usuarioExiste) {
                throw new RuntimeException("El usuario responsable con ID " + tarea.getResponsableId() + " no existe.");
            }
        }
        return tareaRepository.save(tarea);
    }

    public Optional<Tarea> obtenerTareaPorId(Long id) {
        return tareaRepository.findById(id);
    }

    public List<Tarea> obtenerTareasPorEvento(Long eventoId) {
        return tareaRepository.findByEventoId(eventoId);
    }

    public List<Tarea> obtenerTareasPorResponsable(Long responsableId) {
        return tareaRepository.findByResponsableId(responsableId);
    }

    public List<Tarea> obtenerTareasPorEstadoEnEvento(Long eventoId, String estado) {
        return tareaRepository.findByEventoIdAndEstado(eventoId, estado);
    }

    public Tarea actualizarTarea(Long id, Tarea datosActualizados) {
        return tareaRepository.findById(id).map(tarea -> {
            tarea.setNombre(datosActualizados.getNombre());
            tarea.setDescripcion(datosActualizados.getDescripcion());
            tarea.setFechaVencimiento(datosActualizados.getFechaVencimiento());
            tarea.setEstado(datosActualizados.getEstado());

            if (datosActualizados.getEventoId() != null) {
                Boolean eventoExiste = validarEventoExistente(datosActualizados.getEventoId()).block();
                if (eventoExiste == null || !eventoExiste) {
                    throw new RuntimeException("Nuevo Evento con ID " + datosActualizados.getEventoId() + " no encontrado.");
                }
                tarea.setEventoId(datosActualizados.getEventoId());
            }

            if (datosActualizados.getResponsableId() != null) {
                Boolean usuarioExiste = validarUsuarioExistente(datosActualizados.getResponsableId()).block();
                if (usuarioExiste == null || !usuarioExiste) {
                    throw new RuntimeException("Nuevo Responsable con ID " + datosActualizados.getResponsableId() + " no encontrado.");
                }
                tarea.setResponsableId(datosActualizados.getResponsableId());
            }

            return tareaRepository.save(tarea);
        }).orElseThrow(() -> new RuntimeException("Tarea no encontrada con ID: " + id));
    }

    public void eliminarTarea(Long id) {
        tareaRepository.deleteById(id);
    }

    private Mono<Boolean> validarEventoExistente(Long eventoId) {
        return eventoWebClient.get()
                .uri("/{id}", eventoId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar EventoService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(event -> true)
                .defaultIfEmpty(false);
    }

    private Mono<Boolean> validarUsuarioExistente(Long userId) {
        return usuarioWebClient.get()
                .uri("/{id}", userId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar UsuarioService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(user -> true)
                .defaultIfEmpty(false);
    }
}