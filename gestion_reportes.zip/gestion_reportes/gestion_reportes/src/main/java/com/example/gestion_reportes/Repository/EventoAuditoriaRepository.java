package com.example.gestion_reportes.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_reportes.Model.EventoAuditoria;

import java.time.LocalDateTime;
import java.util.List;

public interface EventoAuditoriaRepository extends JpaRepository<EventoAuditoria, Long> {
    List<EventoAuditoria> findByUsuarioId(Long usuarioId);
    List<EventoAuditoria> findByEntidadAfectada(String entidad);
    List<EventoAuditoria> findByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta);
}

