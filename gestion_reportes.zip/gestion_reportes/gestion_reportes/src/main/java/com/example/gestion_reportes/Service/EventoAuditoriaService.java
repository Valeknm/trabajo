package com.example.gestion_reportes.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_reportes.Model.EventoAuditoria;
import com.example.gestion_reportes.Repository.EventoAuditoriaRepository;

import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EventoAuditoriaService {

    @Autowired
    private EventoAuditoriaRepository auditoriaRepository;

    private final WebClient usuarioWebClient;

    public EventoAuditoriaService(WebClient.Builder webClientBuilder) {
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
    }

    public EventoAuditoria registrarEvento(EventoAuditoria evento) {
        if (evento.getUsuarioId() != null) {
            Boolean usuarioExiste = usuarioWebClient.get()
                    .uri("/{id}", evento.getUsuarioId())
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                              response -> Mono.error(new RuntimeException("Error al validar usuario para auditoría: " + response.statusCode())))
                    .bodyToMono(Object.class)
                    .map(u -> true)
                    .defaultIfEmpty(false)
                    .block();

            if (usuarioExiste == null || !usuarioExiste) {
                System.err.println("Advertencia: Intento de registrar auditoría para usuario inexistente con ID: " + evento.getUsuarioId());
            }
        }

        evento.setFechaHora(LocalDateTime.now());
        return auditoriaRepository.save(evento);
    }

    public List<EventoAuditoria> eventosPorUsuario(Long usuarioId) {
        return auditoriaRepository.findByUsuarioId(usuarioId);
    }

    public List<EventoAuditoria> eventosPorEntidad(String entidad) {
        return auditoriaRepository.findByEntidadAfectada(entidad);
    }

    public List<EventoAuditoria> eventosPorRangoFechas(LocalDateTime desde, LocalDateTime hasta) {
        return auditoriaRepository.findByFechaHoraBetween(desde, hasta);
    }

    public List<EventoAuditoria> todos() {
        return auditoriaRepository.findAll();
    }
}