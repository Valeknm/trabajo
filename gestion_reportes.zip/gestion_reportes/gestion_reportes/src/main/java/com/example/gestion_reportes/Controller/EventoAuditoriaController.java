package com.example.gestion_reportes.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gestion_reportes.Model.EventoAuditoria;
import com.example.gestion_reportes.Service.EventoAuditoriaService;

import java.time.LocalDateTime;


@RestController
@RequestMapping("/auditoria")
public class EventoAuditoriaController {

    @Autowired
    private EventoAuditoriaService auditoriaService;

    @PostMapping
    public ResponseEntity<?> registrar(@RequestBody EventoAuditoria evento) {
        try {
            EventoAuditoria registrado = auditoriaService.registrarEvento(evento);
            return ResponseEntity.ok(registrado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error al registrar auditoría: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error inesperado: " + e.getMessage());
        }
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> porUsuario(@PathVariable Long usuarioId) {
        try {
            return ResponseEntity.ok(auditoriaService.eventosPorUsuario(usuarioId));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener eventos por usuario: " + e.getMessage());
        }
    }

    @GetMapping("/entidad/{entidad}")
    public ResponseEntity<?> porEntidad(@PathVariable String entidad) {
        try {
            return ResponseEntity.ok(auditoriaService.eventosPorEntidad(entidad));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener eventos por entidad: " + e.getMessage());
        }
    }

    @GetMapping("/rango")
    public ResponseEntity<?> porFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta) {
        try {
            return ResponseEntity.ok(auditoriaService.eventosPorRangoFechas(desde, hasta));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener eventos por fechas: " + e.getMessage());
        }
    }

    @GetMapping("/todos")
    public ResponseEntity<?> todos() {
        try {
            return ResponseEntity.ok(auditoriaService.todos());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener todos los eventos: " + e.getMessage());
        }
    }
}
