package com.example.gestion_reportes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionReportesApplicationTests {

	@Test
	void contextLoads() {
	}

}
