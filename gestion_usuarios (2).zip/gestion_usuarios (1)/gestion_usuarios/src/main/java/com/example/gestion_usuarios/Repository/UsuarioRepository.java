package com.example.gestion_usuarios.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gestion_usuarios.Model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByCorreo(String correo);
    List<Usuario> findByRol(String rol);
}
