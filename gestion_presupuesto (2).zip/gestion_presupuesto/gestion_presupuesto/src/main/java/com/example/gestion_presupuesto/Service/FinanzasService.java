package com.example.gestion_presupuesto.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_presupuesto.Model.Gasto;
import com.example.gestion_presupuesto.Model.Presupuesto;
import com.example.gestion_presupuesto.Repository.GastoRepository;
import com.example.gestion_presupuesto.Repository.PresupuestoRepository;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class FinanzasService {

    @Autowired
    private PresupuestoRepository presupuestoRepository;
    @Autowired
    private GastoRepository gastoRepository;

    private final WebClient eventoWebClient;

    public FinanzasService(WebClient.Builder webClientBuilder) {
        this.eventoWebClient = webClientBuilder.baseUrl("http://localhost:8082/eventos").build();
    }

    public Presupuesto crearPresupuesto(Presupuesto presupuesto) {
        if (presupuesto.getEventoId() != null) {
            Boolean eventoExiste = validarEventoExistente(presupuesto.getEventoId()).block();
            if (eventoExiste == null || !eventoExiste) {
                throw new RuntimeException("El evento con ID " + presupuesto.getEventoId() + " no existe.");
            }
        }
        return presupuestoRepository.save(presupuesto);
    }

    public Optional<Presupuesto> obtenerPresupuestoPorId(Long id) {
        return presupuestoRepository.findById(id);
    }

    public Optional<Presupuesto> obtenerPresupuestoPorEventoId(Long eventoId) {
        return presupuestoRepository.findByEventoId(eventoId);
    }

    @Transactional
    public Gasto registrarGasto(Long presupuestoId, Gasto gasto) {
        return presupuestoRepository.findById(presupuestoId).map(presupuesto -> {
            gasto.setPresupuestoId(presupuestoId);
            presupuesto.setMontoGastado(presupuesto.getMontoGastado() + gasto.getMonto());
            presupuestoRepository.save(presupuesto);
            return gastoRepository.save(gasto);
        }).orElseThrow(() -> new RuntimeException("Presupuesto no encontrado con ID: " + presupuestoId));
    }

    public List<Gasto> obtenerGastosPorPresupuesto(Long presupuestoId) {
        return gastoRepository.findByPresupuestoId(presupuestoId);
    }

    public List<Gasto> obtenerGastosPorCategoria(String categoria) {
        return gastoRepository.findByCategoria(categoria);
    }

    public Presupuesto actualizarPresupuesto(Long id, Presupuesto datosActualizados) {
        return presupuestoRepository.findById(id).map(presupuesto -> {
            presupuesto.setMontoAsignado(datosActualizados.getMontoAsignado());
            presupuesto.setDescripcion(datosActualizados.getDescripcion());
            // No actualizar montoGastado directamente, solo a través de registrarGasto o ajuste
            return presupuestoRepository.save(presupuesto);
        }).orElseThrow(() -> new RuntimeException("Presupuesto no encontrado con ID: " + id));
    }

    public void eliminarPresupuesto(Long id) {
        presupuestoRepository.deleteById(id);
    }

    public void eliminarGasto(Long id) {
        gastoRepository.findById(id).ifPresent(gasto -> {
            presupuestoRepository.findById(gasto.getPresupuestoId()).ifPresent(presupuesto -> {
                presupuesto.setMontoGastado(presupuesto.getMontoGastado() - gasto.getMonto());
                presupuestoRepository.save(presupuesto);
            });
            gastoRepository.deleteById(id);
        });
    }

    private Mono<Boolean> validarEventoExistente(Long eventoId) {
        return eventoWebClient.get()
                .uri("/{id}", eventoId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar EventoService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(event -> true)
                .defaultIfEmpty(false);
    }
}

