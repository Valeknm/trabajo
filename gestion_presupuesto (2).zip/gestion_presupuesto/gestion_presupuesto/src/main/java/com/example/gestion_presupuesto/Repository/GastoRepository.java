package com.example.gestion_presupuesto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_presupuesto.Model.Gasto;

import java.util.List;

public interface GastoRepository extends JpaRepository<Gasto, Long> {
    List<Gasto> findByPresupuestoId(Long presupuestoId);
    List<Gasto> findByCategoria(String categoria);
}

