package com.example.gestion_presupuesto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPresupuestoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPresupuestoApplication.class, args);
	}

}
