package com.example.gestion_presupuesto.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gestion_presupuesto.Model.Gasto;
import com.example.gestion_presupuesto.Model.Presupuesto;
import com.example.gestion_presupuesto.Service.FinanzasService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping
public class FinanzasController {

    @Autowired
    private FinanzasService finanzasService;

    // Endpoints para Presupuestos
    @PostMapping("/presupuestos")
    public ResponseEntity<Presupuesto> crearPresupuesto(@RequestBody Presupuesto presupuesto) {
        return ResponseEntity.ok(finanzasService.crearPresupuesto(presupuesto));
    }

    @GetMapping("/presupuestos/{id}")
    public ResponseEntity<Presupuesto> obtenerPresupuesto(@PathVariable Long id) {
        Optional<Presupuesto> presupuesto = finanzasService.obtenerPresupuestoPorId(id);
        return presupuesto.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/presupuestos/evento/{eventoId}")
    public ResponseEntity<Presupuesto> obtenerPresupuestoPorEventoId(@PathVariable Long eventoId) {
        Optional<Presupuesto> presupuesto = finanzasService.obtenerPresupuestoPorEventoId(eventoId);
        return presupuesto.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/presupuestos/{id}")
    public ResponseEntity<Presupuesto> actualizarPresupuesto(@PathVariable Long id, @RequestBody Presupuesto presupuesto) {
        return ResponseEntity.ok(finanzasService.actualizarPresupuesto(id, presupuesto));
    }

    @DeleteMapping("/presupuestos/{id}")
    public ResponseEntity<Void> eliminarPresupuesto(@PathVariable Long id) {
        finanzasService.eliminarPresupuesto(id);
        return ResponseEntity.noContent().build();
    }

    // Endpoints para Gastos
    @PostMapping("/presupuestos/{presupuestoId}/gasto")
    public ResponseEntity<Gasto> registrarGasto(@PathVariable Long presupuestoId, @RequestBody Gasto gasto) {
        return ResponseEntity.ok(finanzasService.registrarGasto(presupuestoId, gasto));
    }

    @GetMapping("/gastos/presupuesto/{presupuestoId}")
    public ResponseEntity<List<Gasto>> obtenerGastosPorPresupuesto(@PathVariable Long presupuestoId) {
        return ResponseEntity.ok(finanzasService.obtenerGastosPorPresupuesto(presupuestoId));
    }

    @GetMapping("/gastos/categoria/{categoria}")
    public ResponseEntity<List<Gasto>> obtenerGastosPorCategoria(@PathVariable String categoria) {
        return ResponseEntity.ok(finanzasService.obtenerGastosPorCategoria(categoria));
    }

    @DeleteMapping("/gastos/{id}")
    public ResponseEntity<Void> eliminarGasto(@PathVariable Long id) {
        finanzasService.eliminarGasto(id);
        return ResponseEntity.noContent().build();
    }
}

