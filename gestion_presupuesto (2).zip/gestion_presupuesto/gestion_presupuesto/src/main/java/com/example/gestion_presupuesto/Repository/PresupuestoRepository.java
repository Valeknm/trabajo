package com.example.gestion_presupuesto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_presupuesto.Model.Presupuesto;

import java.util.Optional;

public interface PresupuestoRepository extends JpaRepository<Presupuesto, Long> {
    Optional<Presupuesto> findByEventoId(Long eventoId);
}
