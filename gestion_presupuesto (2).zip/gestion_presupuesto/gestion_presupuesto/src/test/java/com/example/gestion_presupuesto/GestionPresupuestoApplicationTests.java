package com.example.gestion_presupuesto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPresupuestoApplicationTests {

	@Test
	void contextLoads() {
	}

}
