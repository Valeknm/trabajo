package com.example.gestion_soporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionSoporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
