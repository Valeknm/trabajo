package com.example.gestion_soporte.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_soporte.Model.MensajeSoporte;
import com.example.gestion_soporte.Repository.MensajeSoporteRepository;

import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MensajeSoporteService {

    @Autowired
    private MensajeSoporteRepository repository;

    private final WebClient usuarioWebClient;

    public MensajeSoporteService(WebClient.Builder webClientBuilder) {
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
    }

    public MensajeSoporte enviarMensaje(MensajeSoporte mensaje) {
        if (mensaje.getUsuarioId() != null) {
            Boolean usuarioExiste = validarUsuarioExistente(mensaje.getUsuarioId()).block();
            if (usuarioExiste == null || !usuarioExiste) {
                throw new RuntimeException("El usuario con ID " + mensaje.getUsuarioId() + " no es válido para enviar un mensaje de soporte.");
            }
        }

        mensaje.setFechaEnvio(LocalDateTime.now());
        mensaje.setEstado("pendiente");
        return repository.save(mensaje);
    }

    public Optional<MensajeSoporte> obtenerMensaje(Long id) {
        return repository.findById(id);
    }

    public List<MensajeSoporte> listarPorUsuario(Long usuarioId) {
        return repository.findByUsuarioId(usuarioId);
    }

    public List<MensajeSoporte> listarPorEstado(String estado) {
        return repository.findByEstado(estado);
    }

    public MensajeSoporte responderMensaje(Long id, String respuesta) {
        return repository.findById(id).map(mensaje -> {
            mensaje.setRespuesta(respuesta);
            mensaje.setFechaRespuesta(LocalDateTime.now());
            mensaje.setEstado("resuelto");
            return repository.save(mensaje);
        }).orElseThrow(() -> new RuntimeException("Mensaje de soporte no encontrado con ID: " + id));
    }

    private Mono<Boolean> validarUsuarioExistente(Long userId) {
        return usuarioWebClient.get()
                .uri("/{id}", userId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar UsuarioService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(user -> true)
                .defaultIfEmpty(false);
    }
}