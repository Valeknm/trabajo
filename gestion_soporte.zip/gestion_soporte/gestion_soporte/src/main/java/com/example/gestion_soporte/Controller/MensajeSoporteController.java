package com.example.gestion_soporte.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gestion_soporte.Model.MensajeSoporte;
import com.example.gestion_soporte.Service.MensajeSoporteService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/soporte")
public class MensajeSoporteController {

    @Autowired
    private MensajeSoporteService service;

    @PostMapping
    public ResponseEntity<?> enviar(@RequestBody MensajeSoporte mensaje) {
        try {
            MensajeSoporte enviado = service.enviarMensaje(mensaje);
            return ResponseEntity.ok(enviado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al enviar mensaje: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        try {
            Optional<MensajeSoporte> m = service.obtenerMensaje(id);
            if (m.isPresent()) {
                return ResponseEntity.ok(m.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Mensaje no encontrado con ID: " + id);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> porUsuario(@PathVariable Long usuarioId) {
        try {
            List<MensajeSoporte> lista = service.listarPorUsuario(usuarioId);
            return ResponseEntity.ok(lista);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<?> porEstado(@PathVariable String estado) {
        try {
            List<MensajeSoporte> lista = service.listarPorEstado(estado);
            return ResponseEntity.ok(lista);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno: " + e.getMessage());
        }
    }

    @PutMapping("/responder/{id}")
    public ResponseEntity<?> responder(@PathVariable Long id, @RequestBody String respuesta) {
        try {
            MensajeSoporte mensaje = service.responderMensaje(id, respuesta);
            return ResponseEntity.ok(mensaje);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error al responder mensaje: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno: " + e.getMessage());
        }
    }
}
