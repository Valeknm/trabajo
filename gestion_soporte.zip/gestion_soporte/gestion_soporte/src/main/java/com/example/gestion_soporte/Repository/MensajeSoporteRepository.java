package com.example.gestion_soporte.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_soporte.Model.MensajeSoporte;

import java.util.List;

public interface MensajeSoporteRepository extends JpaRepository<MensajeSoporte, Long> {
    List<MensajeSoporte> findByUsuarioId(Long usuarioId);
    List<MensajeSoporte> findByEstado(String estado);
}
