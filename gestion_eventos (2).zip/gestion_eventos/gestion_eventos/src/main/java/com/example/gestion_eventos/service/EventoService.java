package com.example.gestion_eventos.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_eventos.model.Evento;
import com.example.gestion_eventos.repository.EventoRepository;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class EventoService {

    @Autowired
    private EventoRepository eventoRepository;

    private final WebClient usuarioWebClient;

    public EventoService(WebClient.Builder webClientBuilder) {
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
    }

    public Evento crearEvento(Evento evento) {
        // Validar organizadorId
        if (evento.getOrganizadorId() != null) {
            Boolean organizadorValido = validarUsuarioExistente(evento.getOrganizadorId()).block();
            if (organizadorValido == null || !organizadorValido) {
                throw new RuntimeException("Organizador con ID " + evento.getOrganizadorId() + " no encontrado.");
            }
        }

        // Validar planificadorId
        if (evento.getPlanificadorId() != null) {
            Boolean planificadorValido = validarUsuarioExistente(evento.getPlanificadorId()).block();
            if (planificadorValido == null || !planificadorValido) {
                throw new RuntimeException("Planificador con ID " + evento.getPlanificadorId() + " no encontrado.");
            }
        }
        return eventoRepository.save(evento);
    }

    public Optional<Evento> obtenerEventoPorId(Long id) {
        return eventoRepository.findById(id);
    }

    public List<Evento> obtenerEventosPorOrganizador(Long organizadorId) {
        return eventoRepository.findByOrganizadorId(organizadorId);
    }

    public List<Evento> obtenerEventosPorPlanificador(Long planificadorId) {
        return eventoRepository.findByPlanificadorId(planificadorId);
    }

    public Evento actualizarEvento(Long id, Evento datosActualizados) {
        return eventoRepository.findById(id).map(evento -> {
            evento.setNombre(datosActualizados.getNombre());
            evento.setDescripcion(datosActualizados.getDescripcion());
            evento.setFecha(datosActualizados.getFecha());
            evento.setPresupuesto(datosActualizados.getPresupuesto());

            // Re-validar IDs si cambian durante la actualización
            if (datosActualizados.getOrganizadorId() != null) {
                Boolean organizadorValido = validarUsuarioExistente(datosActualizados.getOrganizadorId()).block();
                if (organizadorValido == null || !organizadorValido) {
                    throw new RuntimeException("Nuevo Organizador con ID " + datosActualizados.getOrganizadorId() + " no encontrado.");
                }
                evento.setOrganizadorId(datosActualizados.getOrganizadorId());
            }
            if (datosActualizados.getPlanificadorId() != null) {
                Boolean planificadorValido = validarUsuarioExistente(datosActualizados.getPlanificadorId()).block();
                if (planificadorValido == null || !planificadorValido) {
                    throw new RuntimeException("Nuevo Planificador con ID " + datosActualizados.getPlanificadorId() + " no encontrado.");
                }
                evento.setPlanificadorId(datosActualizados.getPlanificadorId());
            }

            return eventoRepository.save(evento);
        }).orElseThrow(() -> new RuntimeException("Evento no encontrado con ID: " + id));
    }

    public void eliminarEvento(Long id) {
        eventoRepository.deleteById(id);
    }

    private Mono<Boolean> validarUsuarioExistente(Long userId) {
        return usuarioWebClient.get()
                .uri("/{id}", userId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar UsuarioService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(user -> true)
                .defaultIfEmpty(false);
    }
}
