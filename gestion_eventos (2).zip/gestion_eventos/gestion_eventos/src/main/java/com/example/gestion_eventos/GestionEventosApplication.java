package com.example.gestion_eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEventosApplication.class, args);
	}

}
