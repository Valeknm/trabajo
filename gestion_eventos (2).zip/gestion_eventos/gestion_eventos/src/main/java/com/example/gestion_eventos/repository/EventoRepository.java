package com.example.gestion_eventos.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_eventos.model.Evento;

import java.util.List;

public interface EventoRepository extends JpaRepository<Evento, Long> {
    List<Evento> findByOrganizadorId(Long organizadorId);
    List<Evento> findByPlanificadorId(Long planificadorId);
}

