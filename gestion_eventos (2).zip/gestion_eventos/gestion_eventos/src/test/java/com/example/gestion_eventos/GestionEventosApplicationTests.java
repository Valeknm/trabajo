package com.example.gestion_eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
