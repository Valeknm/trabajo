package com.example.gestion_resenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionResenasApplicationTests {

	@Test
	void contextLoads() {
	}

}
