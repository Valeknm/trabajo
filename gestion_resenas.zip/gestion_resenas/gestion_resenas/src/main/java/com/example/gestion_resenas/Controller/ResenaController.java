package com.example.gestion_resenas.Controller;

import com.example.gestion_resenas.Model.Resena;
import com.example.gestion_resenas.Service.ResenaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/resenas")
public class ResenaController {

    @Autowired
    private ResenaService resenaService;

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Resena resena) {
        try {
            Resena nueva = resenaService.crearResena(resena);
            return ResponseEntity.ok(nueva);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error al crear reseña: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error inesperado: " + e.getMessage());
        }
    }

   @GetMapping("/{id}")
public ResponseEntity<Resena> obtener(@PathVariable Long id) {
    try {
        Resena resena = resenaService.obtenerResenaPorId(id)
                .orElseThrow(() -> new RuntimeException("Reseña no encontrada con ID: " + id));
        return ResponseEntity.ok(resena);
    } catch (RuntimeException e) {
        return ResponseEntity.status(404).body(null);
    }
}


    @GetMapping("/evento/{eventoId}")
    public ResponseEntity<?> porEvento(@PathVariable Long eventoId) {
        try {
            List<Resena> resenas = resenaService.obtenerResenasPorEvento(eventoId);
            return ResponseEntity.ok(resenas);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener reseñas por evento: " + e.getMessage());
        }
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<?> porUsuario(@PathVariable Long usuarioId) {
        try {
            List<Resena> resenas = resenaService.obtenerResenasPorUsuario(usuarioId);
            return ResponseEntity.ok(resenas);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error al obtener reseñas por usuario: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            resenaService.eliminarResena(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al eliminar reseña: " + e.getMessage());
        }
    }
}
