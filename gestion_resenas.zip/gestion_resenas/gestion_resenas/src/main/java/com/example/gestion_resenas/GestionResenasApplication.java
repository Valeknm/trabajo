package com.example.gestion_resenas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionResenasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionResenasApplication.class, args);
	}

}
