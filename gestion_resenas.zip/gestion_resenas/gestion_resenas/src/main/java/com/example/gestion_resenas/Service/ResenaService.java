package com.example.gestion_resenas.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_resenas.Model.Resena;
import com.example.gestion_resenas.Repository.ResenaRepository;

import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ResenaService {

    @Autowired
    private ResenaRepository resenaRepository;

    private final WebClient usuarioWebClient;
    private final WebClient eventoWebClient;

    public ResenaService(WebClient.Builder webClientBuilder) {
        this.usuarioWebClient = webClientBuilder.baseUrl("http://localhost:8081/usuarios").build();
        this.eventoWebClient = webClientBuilder.baseUrl("http://localhost:8082/eventos").build();
    }

    public Resena crearResena(Resena resena) {
        if (resena.getUsuarioId() != null) {
            Boolean usuarioExiste = usuarioWebClient.get()
                    .uri("/{id}", resena.getUsuarioId())
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                              response -> Mono.error(new RuntimeException("Error al validar usuario para resena: " + response.statusCode())))
                    .bodyToMono(Object.class)
                    .map(u -> true)
                    .defaultIfEmpty(false)
                    .block();

            if (usuarioExiste == null || !usuarioExiste) {
                throw new RuntimeException("El usuario con ID " + resena.getUsuarioId() + " no existe.");
            }
        }

        if (resena.getEventoId() != null) {
            Boolean eventoExiste = eventoWebClient.get()
                    .uri("/{id}", resena.getEventoId())
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                              response -> Mono.error(new RuntimeException("Error al validar evento para resena: " + response.statusCode())))
                    .bodyToMono(Object.class)
                    .map(e -> true)
                    .defaultIfEmpty(false)
                    .block();

            if (eventoExiste == null || !eventoExiste) {
                throw new RuntimeException("El evento con ID " + resena.getEventoId() + " no existe.");
            }
        }

        resena.setFechaCreacion(LocalDateTime.now());
        return resenaRepository.save(resena);
    }

    public Optional<Resena> obtenerResenaPorId(Long id) {
        return resenaRepository.findById(id);
    }

    public List<Resena> obtenerResenasPorEvento(Long eventoId) {
        return resenaRepository.findByEventoId(eventoId);
    }

    public List<Resena> obtenerResenasPorUsuario(Long usuarioId) {
        return resenaRepository.findByUsuarioId(usuarioId);
    }

    public void eliminarResena(Long id) {
        resenaRepository.deleteById(id);
    }
}