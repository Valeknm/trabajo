package com.example.gestion_resenas.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_resenas.Model.Resena;
import java.util.List;

public interface ResenaRepository extends JpaRepository<Resena, Long> {
    List<Resena> findByEventoId(Long eventoId);
    List<Resena> findByUsuarioId(Long usuarioId);
}
