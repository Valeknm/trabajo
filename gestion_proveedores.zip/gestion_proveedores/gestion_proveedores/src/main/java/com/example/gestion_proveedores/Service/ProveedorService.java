package com.example.gestion_proveedores.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.gestion_proveedores.Model.Proveedor;
import com.example.gestion_proveedores.Repository.ProveedorRepository;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class ProveedorService {

    @Autowired
    private ProveedorRepository proveedorRepository;

    private final WebClient eventoWebClient;

    public ProveedorService(WebClient.Builder webClientBuilder) {
        this.eventoWebClient = webClientBuilder.baseUrl("http://localhost:8082/eventos").build();
    }

    public Proveedor crearProveedor(Proveedor proveedor) {
        if (proveedor.getEventoId() != null) {
            Boolean eventoExiste = validarEventoExistente(proveedor.getEventoId()).block();
            if (eventoExiste == null || !eventoExiste) {
                throw new RuntimeException("El evento con ID " + proveedor.getEventoId() + " no existe.");
            }
        }
        return proveedorRepository.save(proveedor);
    }

    public Optional<Proveedor> obtenerProveedorPorId(Long id) {
        return proveedorRepository.findById(id);
    }

    public List<Proveedor> obtenerProveedoresPorTipoServicio(String tipoServicio) {
        return proveedorRepository.findByTipoServicio(tipoServicio);
    }

    public List<Proveedor> obtenerProveedoresPorEvento(Long eventoId) {
        return proveedorRepository.findByEventoId(eventoId);
    }

    public Proveedor actualizarProveedor(Long id, Proveedor datosActualizados) {
        return proveedorRepository.findById(id).map(proveedor -> {
            proveedor.setNombre(datosActualizados.getNombre());
            proveedor.setContacto(datosActualizados.getContacto());
            proveedor.setTipoServicio(datosActualizados.getTipoServicio());

            if (datosActualizados.getEventoId() != null) {
                Boolean eventoExiste = validarEventoExistente(datosActualizados.getEventoId()).block();
                if (eventoExiste == null || !eventoExiste) {
                    throw new RuntimeException("Nuevo Evento con ID " + datosActualizados.getEventoId() + " no encontrado.");
                }
                proveedor.setEventoId(datosActualizados.getEventoId());
            } else {
                proveedor.setEventoId(null); // Si se elimina la asignación a un evento
            }
            return proveedorRepository.save(proveedor);
        }).orElseThrow(() -> new RuntimeException("Proveedor no encontrado con ID: " + id));
    }

    public void eliminarProveedor(Long id) {
        proveedorRepository.deleteById(id);
    }

    public Proveedor asignarProveedorAEvento(Long proveedorId, Long eventoId) {
        return proveedorRepository.findById(proveedorId).map(proveedor -> {
            if (eventoId != null) {
                Boolean eventoExiste = validarEventoExistente(eventoId).block();
                if (eventoExiste == null || !eventoExiste) {
                    throw new RuntimeException("El evento con ID " + eventoId + " no existe.");
                }
            }
            proveedor.setEventoId(eventoId);
            return proveedorRepository.save(proveedor);
        }).orElseThrow(() -> new RuntimeException("Proveedor no encontrado con ID: " + proveedorId));
    }

    private Mono<Boolean> validarEventoExistente(Long eventoId) {
        return eventoWebClient.get()
                .uri("/{id}", eventoId)
                .retrieve()
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                          response -> Mono.error(new RuntimeException("Error al consultar EventoService: " + response.statusCode())))
                .bodyToMono(Object.class)
                .map(event -> true)
                .defaultIfEmpty(false);
    }
}
