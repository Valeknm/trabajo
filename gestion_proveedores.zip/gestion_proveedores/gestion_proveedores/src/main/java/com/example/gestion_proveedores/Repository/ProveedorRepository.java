package com.example.gestion_proveedores.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_proveedores.Model.Proveedor;

import java.util.List;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {
    List<Proveedor> findByTipoServicio(String tipoServicio);
    List<Proveedor> findByEventoId(Long eventoId);
}

