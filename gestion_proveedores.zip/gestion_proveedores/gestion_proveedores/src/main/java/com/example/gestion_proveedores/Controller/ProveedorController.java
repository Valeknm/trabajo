package com.example.gestion_proveedores.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.gestion_proveedores.Model.Proveedor;
import com.example.gestion_proveedores.Service.ProveedorService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/proveedores")
public class ProveedorController {

    @Autowired
    private ProveedorService proveedorService;

    @PostMapping
    public ResponseEntity<?> crearProveedor(@RequestBody Proveedor proveedor) {
        try {
            Proveedor creado = proveedorService.crearProveedor(proveedor);
            return ResponseEntity.ok(creado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error al crear proveedor: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerProveedor(@PathVariable Long id) {
        try {
            Optional<Proveedor> proveedor = proveedorService.obtenerProveedorPorId(id);
            if (proveedor.isPresent()) {
                return ResponseEntity.ok(proveedor.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Proveedor no encontrado con ID: " + id);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/tipo/{tipoServicio}")
    public ResponseEntity<?> obtenerProveedoresPorTipoServicio(@PathVariable String tipoServicio) {
        try {
            List<Proveedor> lista = proveedorService.obtenerProveedoresPorTipoServicio(tipoServicio);
            return ResponseEntity.ok(lista);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    @GetMapping("/evento/{eventoId}")
    public ResponseEntity<?> obtenerProveedoresPorEvento(@PathVariable Long eventoId) {
        try {
            List<Proveedor> lista = proveedorService.obtenerProveedoresPorEvento(eventoId);
            return ResponseEntity.ok(lista);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProveedor(@PathVariable Long id, @RequestBody Proveedor proveedor) {
        try {
            Proveedor actualizado = proveedorService.actualizarProveedor(id, proveedor);
            return ResponseEntity.ok(actualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Error al actualizar proveedor: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProveedor(@PathVariable Long id) {
        try {
            proveedorService.eliminarProveedor(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar proveedor: " + e.getMessage());
        }
    }

    @PutMapping("/{proveedorId}/asignar/evento/{eventoId}")
    public ResponseEntity<?> asignarProveedorAEvento(@PathVariable Long proveedorId, @PathVariable Long eventoId) {
        try {
            Proveedor asignado = proveedorService.asignarProveedorAEvento(proveedorId, eventoId);
            return ResponseEntity.ok(asignado);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Error al asignar proveedor a evento: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }
}
