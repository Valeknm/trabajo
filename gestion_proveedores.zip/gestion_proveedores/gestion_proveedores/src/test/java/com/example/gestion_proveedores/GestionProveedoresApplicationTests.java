package com.example.gestion_proveedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionProveedoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
